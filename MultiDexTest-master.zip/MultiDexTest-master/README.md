# 今日头条MultiDex优化方案

![今日头条启动](https://upload-images.jianshu.io/upload_images/11562793-4d6b3dec535ccff1.gif?imageMogr2/auto-orient/strip)


---

![仿头条启动.gif](https://upload-images.jianshu.io/upload_images/11562793-451557f2ac97d2ae.gif?imageMogr2/auto-orient/strip)

文章链接：[
面试官：今日头条启动很快，你觉得可能是做了哪些优化？](https://juejin.im/post/5d95f4a4f265da5b8f10714b)
